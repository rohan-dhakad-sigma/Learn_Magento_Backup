<?php
namespace Sigma\SAPIntegration\Observer;
use Magento\Framework\Event\ObserverInterface;

class SapOrderObserver implements ObserverInterface
{
    //  $flag=0;
    protected $logger;
    public function __construct(
        \Magento\Catalog\Model\ProductFactory $productFactory
    )
    {
        $this->_productFactory = $productFactory;
    }
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        try
        {
            $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/temp.log');
            $logger = new \Zend_Log();
            $logger->addWriter($writer);

            $userData = array("username" => "rohan", "password" => "rohan@123");
            $ch = curl_init("http://anothermagento.com/rest/V1/integration/admin/token");
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($userData));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Content-Length: " . strlen(json_encode($userData))));

            $token = curl_exec($ch);

            $ch = curl_init("http://anothermagento.com/rest/V1/orders/1");
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: Bearer " . json_decode($token)));

            $result = curl_exec($ch);

            $result = json_decode($result, 1);
//            echo '<pre>';print_r($result);

            $logger->info(print_r($result));
        }
        catch (\Exception $e)
        {
            $logger->info("from catch block");
        }
    }
}
