<?php

namespace Sigma\MeshGrid\Api\Data;

interface GridInterface
{
    /**
     * Get EntityId.
     *
     * @return int
     */
    public function getId();

    /**
     * @param int $entityId
     * @return mixed
     */
    public function setId($entityId);

    /**
     * @return mixed
     */
    public function getRetry();

    /**
     * @param int $number
     * @return mixed
     */
    public function setRetry($number);

}