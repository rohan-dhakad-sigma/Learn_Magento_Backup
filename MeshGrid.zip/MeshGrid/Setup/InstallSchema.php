<?php

namespace Sigma\MeshGrid\Setup;

class InstallSchema implements \Magento\Framework\Setup\InstallSchemaInterface
{

    public function install(\Magento\Framework\Setup\SchemaSetupInterface $setup, \Magento\Framework\Setup\ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
        if (!$installer->tableExists('api_mesh_grid')) {
            $table = $installer->getConnection()->newTable(
                $installer->getTable('api_mesh_grid')
            )->addColumn(
                    'id',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    null,
                    [
                        'identity' => true,
                        'nullable' => false,
                        'primary'  => true,
                        'unsigned' => true,
                    ],
                    'ID'
                )
                ->addColumn(
                    'retry',
                    \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    255,
                    ['nullable => false'],
                    'Retry'
                )
                ->setComment('Post Table');
            $installer->getConnection()->createTable($table);
            $installer->endSetup();
        }
        $installer->endSetup();
    }
}