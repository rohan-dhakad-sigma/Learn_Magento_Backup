<?php

namespace Sigma\MeshGrid\Model;

use Sigma\MeshGrid\Api\Data\GridInterface;

class Grid extends \Magento\Framework\Model\AbstractModel implements GridInterface
{
    /**
     * CMS page cache tag.
     */
    const CACHE_TAG = 'api_mesh_records';

    /**
     * @var string
     */
    protected $_cacheTag = 'api_mesh_records';

    /**
     * Prefix of model events names.
     *
     * @var string
     */
    protected $_eventPrefix = 'api_mesh_records';

    /**
     * Initialize resource model.
     */
    protected function _construct()
    {
        $this->_init('Sigma\MeshGrid\Model\ResourceModel\Grid');
    }
    /**
     * Get Id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->getData('id');
    }

    /**
     * @param int $entityId
     * @return $this
     */
    public function setId($entityId)
    {
        return $this->setData('id', $entityId);
    }

    /**
     * @return int
     */
    public function getRetry()
    {
        return $this->getData('retry');
    }

    /**
     * @param int $number
     * @return $this
     */
    public function setRetry($number)
    {
        return $this->setData('retry', $number);
    }
}